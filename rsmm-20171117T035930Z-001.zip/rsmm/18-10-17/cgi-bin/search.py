import cgi,cgitb
import os
cgitb.enable()
form=cgi.FieldStorage()
import sqlite3
conn=sqlite3.connect("e-article1.db")
handler = {}
if 'HTTP_COOKIE' in os.environ:
     cookies = os.environ['HTTP_COOKIE']
     cookies = cookies.split('; ')
     for cookie in cookies:
          cookie = cookie.split('=')
          handler[cookie[0]] = cookie[1]
error=0
title=form.getvalue('title')
try:
     a=handler['userid']
     arid=form.getvalue('arid')
     if(arid):
          conn.execute('''insert into sarticles values(?,?)''',(arid,a,))
except:
     error=1;
if(error):
     print('Content-type:text/html')
     print()
     print('''<html>
<head>
	<style type="text/css">
		body{
	background :linear-gradient(to bottom right, white , #999caa) ;
	height: 600px;
}
   
   a{
   	font-family: Hind,sans-serif;
   	font-size: 40px;
   	    -webkit-font-smoothing: antialiased;
   	    color: #515769;
   	    text-decoration: none;
   	    padding: none;
   	    margin: 0px;
   	        background-color: transparent;
   }
   a:hover {
    outline: 0;
    color: #999caa;
    text-decoration: none;
}
	h1{
		 	font-family: Hind,sans-serif;
   	font-size: 40px;
   	    -webkit-font-smoothing: antialiased;
   	    color: #515769;
   	     background-color: transparent;
   	        	    margin: 0px;


	}
</style>

</head>
      <body>
       <center><h1><a href="/cgi-bin/save.py">The acrticle already exists!</a></h1>
       	<h1 style="font-size: 22px">(Click above link to go back)</h1>
       	<h1 style="padding: 0px;margin: 0px">We came to know that you have already saved the article already!</h1>
       	<img src="/images/warn.png" alt="Sorry" height="500" style="padding-top: 0px;">
       </center>
   		</body>
                        
</html>
               ''')
else:
     d=conn.execute('''select * from article where title=?''',(title,))
     rd=d.fetchall()
     if(rd):
          print('Content-type:text/html')
          print()
            
          print('''<!DOCTYPE html>


              <html lang="en" class="no-js">
                  <!-- BEGIN HEAD -->
                  <head>
                  
                 <script type="text/javascript">
                    function preventBack()
                    {
                      window.history.forward();
                      }
                    setTimeout("preventBack()",0);
                    window.onunload=function() { null };
                  </script>
                      <meta charset="utf-8"/>
                      <title>Search Article</title>
                      <meta http-equiv="X-UA-Compatible" content="IE=edge">
                      <meta content="width=device-width, initial-scale=1" name="viewport"/>
                      <meta content="" name="description"/>
                      <meta content="" name="author"/>

                      <!-- GLOBAL MANDATORY STYLES -->
                      <link href="/http://fonts.googleapis.com/css?family=Hind:300,400,500,600,700" rel="stylesheet" type="text/css">
                      <link href="/vendor/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
                      <link href="/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>

                      <!-- PAGE LEVEL PLUGIN STYLES -->
                      <link href="/css/animate.css" rel="stylesheet">
                      <link href="/vendor/swiper/css/swiper.min.css" rel="stylesheet" type="text/css"/>

                      <!-- THEME STYLES -->
                      <link href="/css/layout.min.css" rel="stylesheet" type="text/css"/>

                      <!-- Favicon -->
                      <link rel="/shortcut icon" href="/favicon.ico"/>
                  </head>
                  <!-- END HEAD -->

                  <!-- BODY -->
                  <body>
                  <center><h1><a href="/cgi-bin/view.py">Go back to view articles</a></h1></center>

                      <!--========== HEADER ==========-->
                      
                      <!--========== END HEADER ==========-->

                      <!--========== PARALLAX ==========-->
             
                      <!--========== PARALLAX ==========-->

                      <!--========== PAGE LAYOUT ==========-->
                      <!-- Pricing -->
                   
                      <!-- End Pricing -->

                      <!-- Testimonials -->
                         
                
                      <!-- End Testimonials -->

                      <!-- Clients -->
                           <!-- End Clients -->
                      <!--========== END PAGE LAYOUT ==========-->

                      <!--========== FOOTER ==========-->

                    

                      <!--========== END FOOTER ==========-->
                      ''')
          for each in rd:
               print('''
           
                                      
                                  
                        <div class="content-lg container">
                          <div class="row">
                              <div class="col-sm-9">
                                  <h2>''',each[0],'''</h2>

                                  <!-- Swiper Testimonials -->
                                  <div class="swiper-slider swiper-testimonials">
                                      <!-- Swiper Wrapper -->
                                      <div class="swiper-wrapper">
                          
                                          
                                              <blockquote class="blockquote">
                                                  <div class="margin-b-20">
              <br>
                                                  '''
                                                 ,each[2],'''
                                              
                                                      
                                                  </div>
                                                  <p><span class="fweight-700 color-link">''',each[1],'''</span></p>
                                              </blockquote>       
                                      </div>
                                      <form action="/cgi-bin/view.py" method="post">
                                       <input type="text" name="arid" value="''',each[4],'''"  hidden />
                                        <input type="text" name="title" value="''',title,'''"  hidden />
                                        <button type="submit" class="btn-theme btn-theme-sm btn-base-bg text-uppercase" >save article</button>
                                        </form>
                                      <!-- End Swiper Wrapper -->
                                      <!-- Pagination -->
                                      <div class="swiper-testimonials-pagination"></div>
                                  </div>
                                  <!-- End Swiper Testimonials -->
                                  
                              </div>
                          </div>
                          <!--// end row -->
                      </div>
                      <hr style="height: 12px;
                       border: 0;
                       box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 2);">''')
          print('''
                

                      <!-- Back To Top -->
                      <a href="javascript:void(0);" class="js-back-to-top back-to-top">Top</a>

                      <!-- JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
                      <!-- CORE PLUGINS -->
                      <script src="/vendor/jquery.min.js" type="text/javascript"></script>
                      <script src="/vendor/jquery-migrate.min.js" type="text/javascript"></script>
                      <script src="/vendor/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

                      <!-- PAGE LEVEL PLUGINS -->
                      <script src="/vendor/jquery.easing.js" type="text/javascript"></script>
                      <script src="/vendor/jquery.back-to-top.js" type="text/javascript"></script>
                      <script src="/vendor/jquery.smooth-scroll.js" type="text/javascript"></script>
                      <script src="/vendor/jquery.wow.min.js" type="text/javascript"></script>
                      <script src="/vendor/jquery.parallax.min.js" type="text/javascript"></script>
                      <script src="/vendor/swiper/js/swiper.jquery.min.js" type="text/javascript"></script>

                      <!-- PAGE LEVEL SCRIPTS -->
                      <script src="/js/layout.min.js" type="text/javascript"></script>
                      <script src="/js/components/wow.min.js" type="text/javascript"></script>
                      <script src="/js/components/swiper.min.js" type="text/javascript"></script>

                  </body>
                  <!-- END BODY -->
              </html>''')

     else:
          print('''Content-type:text/html''')
          print()
          print('''<html>
<head>
	<style type="text/css">
		body{
	background :linear-gradient(to bottom right, white , #999caa) ;
	height: 600px;
}
   
   a{
   	font-family: Hind,sans-serif;
   	font-size: 40px;
   	    -webkit-font-smoothing: antialiased;
   	    color: #515769;
   	    text-decoration: none;
   	    padding: none;
   	    margin: 0px;
   	        background-color: transparent;
   }
   a:hover {
    outline: 0;
    color: #999caa;
    text-decoration: none;
}
	h1{
		 	font-family: Hind,sans-serif;
   	font-size: 40px;
   	    -webkit-font-smoothing: antialiased;
   	    color: #515769;
   	     background-color: transparent;
   	        	    margin: 0px;


	}
</style>

</head>
      <body>
       <center><h1><a href="/cgi-bin/view.py">No search found</a></h1>
       	<h1 style="font-size: 22px">(Click above link to go back)</h1>
       	<h1 style="padding: 0px;margin: 0px">Our search is case sensitive try a different way</h1>
       	<img src="/images/warn.png" alt="Sorry" height="500" style="padding-top: 0px;">
       </center>
   		</body>
                        
</html>
                        ''')
    
conn.commit()
conn.close()     
