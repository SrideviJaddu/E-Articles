import cgi,cgitb,sqlite3
cgitb.enable()
form=cgi.FieldStorage()
import random as r
a=r.randrange(1000,9999,1)
ltype=form.getvalue('ltype')
if ltype=='User':
    email = form.getvalue("email")
    password= 'rsmmrsmm'
    import sqlite3
    conn=sqlite3.connect('e-article1.db')
    d=conn.execute('''select email from users''')
    data=d.fetchall()
    """fname = form.getvalue("fname")
    lname = form.getvalue("lname")
    phno = form.getvalue("")
    password = form.getvalue("password")
    username = form.getvalue("username")

    conn = sqlite3.connect('searchengine.db')
    conn.execute('''insert into registration(username,phno,email,password)
    values(?,?,?,?)''',(username,phno,email,password))
    inf = conn.execute('''select username,password from registration''')
    data=inf.fetchall()"""
    k=0
    for i in data:
        if(i[0]==email):
            k=1
    if(k==1):
        otp = a
        otpstring = str(otp)
    #httpstring = '<html><body><h1><a href="/cgi-bin/test.py">Click here to change password</h1></body></html>'
        print('Set-Cookie:email=',email)
        print ('Set-Cookie:otp=',otp)
        print ('Set-Cookie:ltype=',ltype)
        print ('Set-Cookie:Expires=Monday, 25-Dec-2017 15:20:00 GMT')
        print("Content-type:text/html")
        print()
        print('''<!DOCTYPE html>
    <!-- Template by Quackit.com -->
    <!-- Images by various sources under the Creative Commons CC0 license and/or the Creative Commons Zero license. 
    Although you can use them, for a more unique website, replace these images with your own. -->
    <html lang="en">

    <head>
         <link rel="stylesheet" href="/https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

      <link rel='stylesheet prefetch' href='/https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
    <link rel='stylesheet prefetch' href='/https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

          <link rel="stylesheet" href="/css/style.css">

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <title>OTP verification</title>

        <!-- Bootstrap Core CSS -->
        <link href="/css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles -->
        <link href="/css/custom.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="/https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="/https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Custom Fonts from Google -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
        
    </head>

    <body>

        <!-- Navigation -->
        <nav id="siteNav" class="navbar navbar-default navbar-fixed-top" role="navigation" >
             <div class="container">
                <!-- Logo and responsive toggle -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#" style="color: green">
                            <span class="glyphicon glyphicon-fire"></span> 
                            RSMM-Articles
                    </a>
                </div>
                <!-- Navbar links -->
                <div class="collapse navbar-collapse" id="navbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active">
                            <a href="/index.html">Home</a>
                        </li>
                      
                    </ul>
                    
                </div><!-- /.navbar-collapse -->
            </div>
               
                <!-- Navbar links --><!-- /.navbar-collapse -->
            </div><!-- /.container -->
        </nav>

        <!-- Header -->
     

        <!-- Intro Section -->


        <!-- Content 1 -->
        <section class="content">
            <div class="container">
                <div class="row">
                
                 
     
                         
                         <div class="pen-title">
      <h1>Forgot Password</h1><span><a href='#'>We have sent you an OTP check ur email user </a></span>
    </div>
    <!-- Form Module-->
    <div class="module form-module">
      <div>
        <div class="tooltip">Click Me</div>
      </div>
      <div class="form">
        <h2>Verify OTP</h2>
        <form action='/cgi-bin/verify.py' method='post'>
            <div style="width: 100% ">
            <!--    <select style="width: 100%" name="ltype">
                <option value="Admin">Admin</option>
                <option value="User">User</option>
            </select>-->
            </div> 
            
            

          <input type="text" placeholder="Enter OTP" name="otp" />
    <!--       <input type="password" placeholder="Password" name="password" />
     -->      <BUTTON type="submit">Verify OTP</BUTTON>    
    </form>
       
      </div>
      <div class="module form-module"></div>
    </div>
                    
    <!-- Form Module-->

                             
                    
                </div>
            </div>
        </section>

        <!-- Content 2 -->


        <!-- Promos -->
        <div class="container-fluid">
            <div class="row promo">
          
      
                
            
            </div>
        </div><!-- /.container-fluid -->

        <!-- Content 3 -->

        
        <!-- Footer -->
        <footer class="page-footer">
        
            <!-- Contact Us -->
             <div class="contact" style="background: #33b5e5">
                <div class="container">
                    <h2 class="section-heading">Contact Us</h2>
                    <p><span class="glyphicon glyphicon-earphone"></span><br> +91 9502 80 4211</p>
                    <p><span class="glyphicon glyphicon-envelope"></span><br> rsmm.articles@gmail.com</p>
                </div>
            </div>
                
            <!-- Copyright etc -->
            <div class="small-print">
                <div class="container">
                    <p>Copyright &copy; RSMM-ARTICLES 2015</p>
                </div>
            </div>
            
        </footer>

        <!-- jQuery -->
        <script src="/js/jquery-1.11.3.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="/js/bootstrap.min.js"></script>

        <!-- Plugin JavaScript -->
        <script src="/js/jquery.easing.min.js"></script>
        
        <!-- Custom Javascript -->
        <script src="/js/custom.js"></script>
          <script src='/http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script  src="/js/index.js"></script>

    </body>

    </html>
    ''')


        #MAIL SENDING
        import smtplib
        from email.mime.multipart import MIMEMultipart
        from email.mime.base import MIMEBase
        from email.mime.text import MIMEText
        from email.utils import COMMASPACE, formatdate
        from email import encoders
        import os
        import datetime

        smtpUser = 'rsmm.articles@gmail.com'
        smtpPass = password
        sendstring = 'this is the string that has to be sent to the email the otp of ur  account change password :'+otpstring
            #sendstring = sendstring+httpstring
        COMMASPACE = ', '


        def sendMail(to, subject, text, files=[]):
            assert type(to)==list
            assert type(files)==list

            msg = MIMEMultipart()
            msg['From'] = smtpUser
            msg['To'] = COMMASPACE.join(to)
            msg['Date'] = formatdate(localtime=True)
            msg['Subject'] = 'Mail sending Test'

            msg.attach( MIMEText(text) )

            for file in files:
                part = MIMEBase('application', "octet-stream")
                part.set_payload( open(file,"rb").read() )
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', 'attachment; filename="%s"'
                                   % os.path.basename(file))
                msg.attach(part)

            server = smtplib.SMTP('smtp.gmail.com:587')
            server.ehlo_or_helo_if_needed()
            server.starttls()
            server.ehlo_or_helo_if_needed()
            server.login(smtpUser,smtpPass)
            server.sendmail(smtpUser, to, msg.as_string())
            print ('Done')
            server.quit()

        sendMail( [email],'Are u receiving this bloody email?',sendstring)
    else:
        print("Content-type:text/html")
        print()
        print('''<html>
<head>
	<style type="text/css">
		body{
	background :linear-gradient(to bottom right, white , #999caa) ;
	height: 600px;
}
   
   a{
   	font-family: Hind,sans-serif;
   	font-size: 40px;
   	    -webkit-font-smoothing: antialiased;
   	    color: #515769;
   	    text-decoration: none;
   	    padding: none;
   	    margin: 0px;
   	        background-color: transparent;
   }
   a:hover {
    outline: 0;
    color: #999caa;
    text-decoration: none;
}
	h1{
		 	font-family: Hind,sans-serif;
   	font-size: 40px;
   	    -webkit-font-smoothing: antialiased;
   	    color: #515769;
   	     background-color: transparent;
   	        	    margin: 0px;


	}
</style>

</head>
      <body>
       <center><h1><a href="/cgi-bin/test.py">The User Mail doesnt exists!</a></h1>
       	<h1 style="font-size: 22px">(Click above link to Register)</h1>
       	<h1 style="padding: 0px;margin: 0px">There is no such account with this email please make sure u entered correct email!
        
       	</h1>
       <div>	<a href="/forgot.html">Click here to Re-enter mail</a></div>
       	<div>
       	<img src="/images/warn.png" alt="Sorry" height="500" style="padding-top: 0px;">
       	</div>
       </center>
   		</body>
                        
</html>''')
    
if ltype=='Admin':
    email = form.getvalue("email")
    password = 'rsmmrsmm'
  
    import sqlite3
    conn=sqlite3.connect('e-article1.db')
    d=conn.execute('''select aemail from admin''')
    data=d.fetchall()
    k=0
    for i in data:
        if(i[0]==email):
            k=1
    if(k==1):
        otp = a
        otpstring = str(otp)
    #httpstring = '<html><body><h1><a href="/cgi-bin/test.py">Click here to change password</h1></body></html>'
        print('Set-Cookie:email=',email)
        print ('Set-Cookie:otp=',otp)
        print('Set-Cookie:ltype=',ltype)
        print ('Set-Cookie:Expires=Monday, 25-Dec-2017 15:20:00 GMT')
        print("Content-type:text/html")
        print()
        print('''<!DOCTYPE html>
    <!-- Template by Quackit.com -->
    <!-- Images by various sources under the Creative Commons CC0 license and/or the Creative Commons Zero license. 
    Although you can use them, for a more unique website, replace these images with your own. -->
    <html lang="en">

    <head>
         <link rel="stylesheet" href="/https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

      <link rel='stylesheet prefetch' href='/https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
    <link rel='stylesheet prefetch' href='/https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

          <link rel="stylesheet" href="/css/style.css">

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <title>OTP verification</title>

        <!-- Bootstrap Core CSS -->
        <link href="/css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles -->
        <link href="/css/custom.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="/https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="/https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Custom Fonts from Google -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
        
    </head>

    <body>

        <!-- Navigation -->
        <nav id="siteNav" class="navbar navbar-default navbar-fixed-top" role="navigation" >
             <div class="container">
                <!-- Logo and responsive toggle -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#" style="color: green">
                            <span class="glyphicon glyphicon-fire"></span> 
                            RSMM-Articles
                    </a>
                </div>
                <!-- Navbar links -->
                <div class="collapse navbar-collapse" id="navbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active">
                            <a href="/index.html">Home</a>
                        </li>
                      
                    </ul>
                    
                </div><!-- /.navbar-collapse -->
            </div>
               
                <!-- Navbar links --><!-- /.navbar-collapse -->
            </div><!-- /.container -->
        </nav>

        <!-- Header -->
     

        <!-- Intro Section -->


        <!-- Content 1 -->
        <section class="content">
            <div class="container">
                <div class="row">
                
                 
     
                         
                         <div class="pen-title">
      <h1>Forgot Password</h1><span><a href='#'>We have sent you an OTP check ur email Admin</a></span>
    </div>
    <!-- Form Module-->
    <div class="module form-module">
      <div>
        <div class="tooltip">Click Me</div>
      </div>
      <div class="form">
        <h2>Verify OTP</h2>
        <form action='/cgi-bin/verify.py' method='post'>
            <div style="width: 100% ">
            <!--    <select style="width: 100%" name="ltype">
                <option value="Admin">Admin</option>
                <option value="User">User</option>
            </select>-->
            </div> 
            
            

          <input type="text" placeholder="Enter OTP" name="otp" />
    <!--       <input type="password" placeholder="Password" name="password" />
     -->      <BUTTON type="submit">Verify OTP</BUTTON>    
    </form>
       
      </div>
      <div class="module form-module"></div>
    </div>
                    
    <!-- Form Module-->

                             
                    
                </div>
            </div>
        </section>

        <!-- Content 2 -->


        <!-- Promos -->
        <div class="container-fluid">
            <div class="row promo">
          
      
                
            
            </div>
        </div><!-- /.container-fluid -->

        <!-- Content 3 -->

        
        <!-- Footer -->
        <footer class="page-footer">
        
            <!-- Contact Us -->
             <div class="contact" style="background: #33b5e5">
                <div class="container">
                    <h2 class="section-heading">Contact Us</h2>
                    <p><span class="glyphicon glyphicon-earphone"></span><br> +91 9502 80 4211</p>
                    <p><span class="glyphicon glyphicon-envelope"></span><br> rsmm.articles@gmail.com</p>
                </div>
            </div>
                
            <!-- Copyright etc -->
            <div class="small-print">
                <div class="container">
                    <p>Copyright &copy; RSMM-ARTICLES 2015</p>
                </div>
            </div>
            
        </footer>

        <!-- jQuery -->
        <script src="/js/jquery-1.11.3.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="/js/bootstrap.min.js"></script>

        <!-- Plugin JavaScript -->
        <script src="/js/jquery.easing.min.js"></script>
        
        <!-- Custom Javascript -->
        <script src="/js/custom.js"></script>
          <script src='/http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script  src="/js/index.js"></script>

    </body>

    </html>''')


            #MAIL SENDING
        import smtplib
        from email.mime.multipart import MIMEMultipart
        from email.mime.base import MIMEBase
        from email.mime.text import MIMEText
        from email.utils import COMMASPACE, formatdate
        from email import encoders
        import os
        import datetime

        smtpUser = 'rsmm.articles@gmail.com'
        smtpPass = password
        sendstring = 'this is the string that has to be sent to the email the otp of ur  account change password :'+otpstring
            #sendstring = sendstring+httpstring
        COMMASPACE = ', '


        def sendMail(to, subject, text, files=[]):
            assert type(to)==list
            assert type(files)==list

            msg = MIMEMultipart()
            msg['From'] = smtpUser
            msg['To'] = COMMASPACE.join(to)
            msg['Date'] = formatdate(localtime=True)
            msg['Subject'] = 'Mail sending Test'

            msg.attach( MIMEText(text) )

            for file in files:
                part = MIMEBase('application', "octet-stream")
                part.set_payload( open(file,"rb").read() )
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', 'attachment; filename="%s"'
                                   % os.path.basename(file))
                msg.attach(part)

            server = smtplib.SMTP('smtp.gmail.com:587')
            server.ehlo_or_helo_if_needed()
            server.starttls()
            server.ehlo_or_helo_if_needed()
            server.login(smtpUser,smtpPass)
            server.sendmail(smtpUser, to, msg.as_string())
            print ('Done')
            server.quit()

        sendMail( [email],'Are u receiving this bloody email?',sendstring)

    else:
        print("Content-type:text/html")
        print()
        print('''<html>
<head>
	<style type="text/css">
		body{
	background :linear-gradient(to bottom right, white , #999caa) ;
	height: 600px;
}
   
   a{
   	font-family: Hind,sans-serif;
   	font-size: 40px;
   	    -webkit-font-smoothing: antialiased;
   	    color: #515769;
   	    text-decoration: none;
   	    padding: none;
   	    margin: 0px;
   	        background-color: transparent;
   }
   a:hover {
    outline: 0;
    color: #999caa;
    text-decoration: none;
}
	h1{
		 	font-family: Hind,sans-serif;
   	font-size: 40px;
   	    -webkit-font-smoothing: antialiased;
   	    color: #515769;
   	     background-color: transparent;
   	        	    margin: 0px;


	}
</style>

</head>
      <body>
       <center><h1><a href="/cgi-bin/test.py">The Admin Mail doesnt exists!</a></h1>
       	<h1 style="font-size: 22px">(Click above link to Register)</h1>
       	<h1 style="padding: 0px;margin: 0px">There is no such account with this email please make sure u entered correct email!</br>
        <a href="/forgot.html">Click here to Re-enter mail</a>
       	</h1>
       	
       	<img src="/images/warn.png" alt="Sorry" height="500" style="padding-top: 0px;">
       </center>
   		</body>
                        
</html>''')
     


