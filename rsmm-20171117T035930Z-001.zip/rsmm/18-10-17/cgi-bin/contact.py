import cgi,cgitb
cgitb.enable()
form=cgi.FieldStorage()
import sqlite3
conn=sqlite3.connect("e-article1.db")
d= conn.execute('''select username from users''')
ud= d.fetchall()
d= conn.execute('''select ausername from admin''')
ud1= d.fetchall()

print("content-type:text/html")
print()
print('''<!DOCTYPE html>
<!-- Template by Quackit.com -->
<!-- Images by various sources under the Creative Commons CC0 license and/or the Creative Commons Zero license. 
Although you can use them, for a more unique website, replace these images with your own. -->
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>About us</title>

    <!-- Bootstrap Core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles -->
    <link href="/css/custom.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="/https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="/https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom Fonts from Google -->
    <link href='/http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    
</head>

<body>

    <!-- Navigation -->
    <nav id="siteNav" class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Logo and responsive toggle -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">
                	<span class="glyphicon glyphicon-fire"></span> 
                	RSMM-Articles
                </a>
            </div>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="/index.html">Home</a>
                    </li>
                    <li >
                        <a href="/cgi-bin/test.py">Login/reg</a>
                    </li>
				
                    <li style="color:black">
                        <a href="/cgi-bin/contact.py">about us</a>
                    </li>
                </ul>
                
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container -->
    </nav>

	<!-- Header -->


	<!-- Intro Section -->
    <section class="intro">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                	<span class="glyphicon glyphicon-fire" style="font-size: 60px"></span>
                    <h2 class="section-heading">RSMM is the open access website for students and scholars featuring high quality scholarly content and student-facing resources</h2>
                   
                    <p>The website was established in october 2017</p> <p>We provide platform to all the students to publish their articles</p>
                    <p> In addition we also provide best articles for their research</p>
                        
                       
                    </ul>
                </div>
            </div>
        </div>
    </section>

	<!-- Content 1 -->
    <section class="content">
        <div class="container">
            <div class="row">
                
                   
                	<h2 class="section-header">OUR GOALS</h2>
                	<p class="lead text-muted"><span class="glyphicon glyphicon-fire"></span> To provide the best source of freely available articles for students belonging to various fields.
                    <p class="lead text-muted"><span class="glyphicon glyphicon-fire"></span> Provides free platform to students belonging to various fields to publish their articles.</p> 
                    <p class="lead text-muted"><span class="glyphicon glyphicon-fire"></span> To be the upcoming open access scholarly publisher in our fields,making reputable expert content free to view for all</p>

                	
                           
                
            </div>
        </div>
    </section>

	<!-- Content 2 -->
     <section class="content content-2">
        <div class="container">
            <div class="row">
                	<h2 class="section-header">OUR TEAM</h2>
                	<p class="lead text-light"><span class="glyphicon glyphicon-fire"></span> RSMM articles is staffed by an all volunteer team of academics and s</p>
                    <p class="lead text-light"><span class="glyphicon glyphicon-fire"></span> We give up some of our time because we want to have a hand in furthering RSMM's goal of creating a unique resources for students and scholars</p>
                    <p class="lead text-light"><span class="glyphicon glyphicon-fire"></span> If you would like to join our team and get involved,in our work you can contact us
</p>
                    

               
                </div>            
                
            </div>
        </div>
    </section>    

    <!-- Promos -->
<!-- /.container-fluid -->

	<!-- Content 3 -->
     <section class="content">
        <div class="container">
            <center><h2 class="section-header"><span class="glyphicon glyphicon-pushpin text-primary"></span><br> Admin Team</h2></center>''')
l1=[]
for i in ud1:
    l1.append(i[0])
length1=len(l1)
for i in range(0,length1,3):
    j=i+1
    if(j<length1):
        k=j+1
        if(k<length1):
            print('''
<div class="container">
                    <div class="row">
                      <div class="col-sm-4">
                    <p class="lead text-muted"><span class="glyphicon glyphicon-fire"> ''',l1[i],'''</span></p>
                          
                       </div>
                       <div class="col-sm-4">                          
                         <p class="lead text-muted"><span class="glyphicon glyphicon-fire"> ''',l1[j],'''</span></p>
                       </div>
                       <div class="col-sm-4">
                        <p class="lead text-muted"><span class="glyphicon glyphicon-fire"> ''',l1[k],'''</span></p>
                       </div>
                       
                    </div>
</div>
''')
            
        else:
            print('''<div class="container">
                    <div class="row">
                      <div class="col-sm-4">
                     <p class="lead text-muted"><span class="glyphicon glyphicon-fire"> ''',l1[i],'''</span></p>
                          
                       </div>
                       <div class="col-sm-4">                          
                         <p class="lead text-muted"><span class="glyphicon glyphicon-fire"> ''',l1[j],'''</span></p>
                       </div>
                       
                    </div>
</div>''')
            
    else:
        print('''<div class="container">
                    <div class="row">
                      <div class="col-sm-4">
                    <p class="lead text-muted"><span class="glyphicon glyphicon-fire"> ''',l1[i],'''</span></p>
                          
                       </div>
                       
                    </div>
</div>''')
print('''
                             
            </div>
        </div>
    </section>



        <section class="content content-2">
        <div class="container">
            <div class="row">
                <center><h2 class="section-header"><span class="glyphicon glyphicon-pushpin text-primary"></span><br> Articles Team</h2></center>''')
l=[]
for i in ud:
    l.append(i[0])
length=len(l)
for i in range(0,length,3):
    j=i+1
    if(j<length):
        k=j+1
        if(k<length):
            print('''<div class="container">
                    <div class="row">
                      <div class="col-sm-4">
                    <p class="lead text-muted"><span class="glyphicon glyphicon-fire"> ''',l[i],'''</span></p>
                          
                       </div>
                       <div class="col-sm-4">                          
                         <p class="lead text-muted"><span class="glyphicon glyphicon-fire"> ''',l[j],'''</span></p>
                       </div>
                       <div class="col-sm-4">
                        <p class="lead text-muted"><span class="glyphicon glyphicon-fire"> ''',l[k],'''</span></p>
                       </div>
                       
                    </div>
</div>''')
            
        else:
            print('''<div class="container">
                    <div class="row">
                      <div class="col-sm-4">
                     <p class="lead text-muted"><span class="glyphicon glyphicon-fire"> ''',l[i],'''</span></p>
                          
                       </div>
                       <div class="col-sm-4">                          
                         <p class="lead text-muted"><span class="glyphicon glyphicon-fire"> ''',l[j],'''</span></p>
                       </div>
                       
                    </div>
</div>''')
            
    else:
        print('''<div class="container">
                    <div class="row">
                      <div class="col-sm-4">
                    <p class="lead text-muted"><span class="glyphicon glyphicon-fire"> ''',l[i],'''</span></p>
                          
                       </div>
                       
                    </div>
</div>''')

print('''
                

               
                </div>            
                
            </div>
        </div>
    </section> 
    
	<!-- Footer -->
    <footer class="page-footer">
    
    	<!-- Contact Us -->
        <div class="contact">
        	<div class="container">
				<h2 class="section-heading">Meet The Developers </h2>
				<p><b>Sri Devi</b></p>
				<p><b>Mouna</b></p>
                <P><b>Mounika</b></P>
                <p><b>Rahul</b></p>
        	</div>
        </div>
        	
        <!-- Copyright etc -->
        <div class="small-print">
        	<div class="container">
        		<p>Copyright &copy; RSMM-ARTICLES 2015</p>
        	</div>
        </div>
        
    </footer>

    <!-- jQuery -->
    <script src="/js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="/js/jquery.easing.min.js"></script>
    
    <!-- Custom Javascript -->
    <script src="/js/custom.js"></script>

</body>

</html>''')
