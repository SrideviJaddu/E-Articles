import cgi,cgitb
import os
cgitb.enable()
form=cgi.FieldStorage()
title=form.getvalue('Title')
author=form.getvalue('Author')
content=form.getvalue('Article')
status=0
import sqlite3
conn=sqlite3.connect("e-article1.db")
handler = {}
if 'HTTP_COOKIE' in os.environ:
     cookies = os.environ['HTTP_COOKIE']
     cookies = cookies.split('; ')
     for cookie in cookies:
          cookie = cookie.split('=')
          handler[cookie[0]] = cookie[1]
     if title:
          conn.execute('''insert into article(title,author,content,status,userid)
             values(?,?,?,?,?)''',(title,author,content,status,handler['userid']))
     



print('Content-type:text/html')
print()
print('''<!DOCTYPE html>

<html lang="en" class="no-js">
    <!-- BEGIN HEAD -->
    <head>
    
   <script type="text/javascript">
      function preventBack()
      {
        window.history.forward();
        }
      setTimeout("preventBack()",0);
      window.onunload=function() { null };
    </script>
        <meta charset="utf-8"/>
        <title>Metronic "Asentus" Frontend Freebie</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <meta content="" name="description"/>
        <meta content="" name="author"/>

        <!-- GLOBAL MANDATORY STYLES -->
        <link href="/http://fonts.googleapis.com/css?family=Hind:300,400,500,600,700" rel="stylesheet" type="text/css">
        <link href="/vendor/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
        <link href="/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>

        <!-- PAGE LEVEL PLUGIN STYLES -->
        <link href="/css/animate.css" rel="stylesheet">
        <link href="/vendor/swiper/css/swiper.min.css" rel="stylesheet" type="text/css"/>

        <!-- THEME STYLES -->
        <link href="/css/layout.min.css" rel="stylesheet" type="text/css"/>

        <!-- Favicon -->
        <link rel="/shortcut icon" href="/favicon.ico"/>
    </head>
    <!-- END HEAD -->

    <!-- BODY -->
    <body>

        <!--========== HEADER ==========-->
        <header class="header navbar-fixed-top">
            <!-- Navbar -->
            <nav class="navbar" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="menu-container">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".nav-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="toggle-icon"></span>
                        </button>

                        <!-- Logo -->
                        <div class="logo">
                            <a class="logo-wrap" href="index.html">
                                <img class="logo-img logo-img-main" src="/img/logo.png" alt="Asentus Logo">
                                <img class="logo-img logo-img-active" src="/img/logo-dark.png" alt="Asentus Logo">
                            </a>
                        </div>
                        <!-- End Logo -->
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse nav-collapse">
                        <div class="menu-container">
                            <ul class="navbar-nav navbar-nav-right">
                                <li class="nav-item"><a class="nav-item-child nav-item-hover active" href="/cgi-bin/profile1.py">''',handler['username'],'''</a></li>
                                <li class="nav-item"><a class="nav-item-child nav-item-hover" href="/cgi-bin/view.py">view Articles</a></li>
                                 <li class="nav-item"><a class="nav-item-child nav-item-hover" href="/cgi-bin/myarticles.py">My Articles</a></li>
                                  <li class="nav-item"><a class="nav-item-child nav-item-hover" href="/cgi-bin/save.py">saved articles</a></li>
                                  <li class="nav-item"><a class="nav-item-child nav-item-hover" href="/cgi-bin/test.py">Log-out</a></li>


                             
                            </ul>
                        </div>
                    </div>
                    <!-- End Navbar Collapse -->
                </div>
            </nav>
            <!-- Navbar -->
        </header>
        <!--========== END HEADER ==========-->

        <!--========== PARALLAX ==========-->
        <div class="parallax-window" data-parallax="scroll" data-image-src="/img/1920x1080/01.jpg">
            <div class="parallax-content container">
                <h3 style="font-size: 40px" class="carousel-title">Welcome to RSMM</h3>
                <p>This is a place where you are going to exlpore everything. Add your own articles and more<br/> Happy reading ;)</p>
                <b><p>Scroll Down to Login</p></b>
            </div>
        </div>
        <!--========== PARALLAX ==========-->

        <!--========== PAGE LAYOUT ==========-->
        <!-- Pricing -->
     
        <!-- End Pricing -->

        <!-- Testimonials -->
           
  
        <!-- End Testimonials -->

        <!-- Clients -->
             <!-- End Clients -->
        <!--========== END PAGE LAYOUT ==========-->

        <!--========== FOOTER ==========-->
        <footer class="footer" style="background: #3B3738">
            <!-- Links -->
            <div class="footer-seperator">
                <div class="content-lg container">
                    <div class="row">
               
                    
                        <div class="col-sm-5 sm-margin-b-30">
                            <h2 class="color-white" >Add Article Here</h2>
                            <form action='profile1.py' method='post'>
                                <input type="text" class="form-control footer-input margin-b-20" name="Title" placeholder="Title" required>
                                <input type="text" class="form-control footer-input margin-b-20" name="Author" placeholder="Author" required>
                                <textarea class="form-control footer-input margin-b-30" rows="6" name="Article" placeholder="Your Article Here" required></textarea>
                                <input type="hidden" name="arid">
                                <input type="hidden" name="status" value="0">

                                <button type="submit" class="btn-theme btn-theme-sm btn-base-bg text-uppercase">Add Article</button>
                            </form>
                            
<!--                             <input type="email" class="form-control footer-input margin-b-20" placeholder="Email" required>
 -->                            
<!--                             <textarea class="form-control footer-input margin-b-30" rows="6" placeholder="Message" required></textarea>
 -->                            
                        </div>
                    </div>
                    <!--// end row -->
                </div>
            </div>
            <!-- End Links -->

            <!-- Copyright -->
            <div class="content container">
                <div class="row">
                    <div class="col-xs-6">
                        <img class="footer-logo" src="img/logo.png" alt="Asentus Logo">
                    </div>
                    <div class="col-xs-6 text-right">
                        <p class="margin-b-0"><a class="color-base fweight-700" href="http://keenthemes.com/preview/asentus/">Asentus</a> Theme Powered by: <a class="color-base fweight-700" href="http://www.keenthemes.com/">KeenThemes.com</a></p>
                    </div>
                </div>
                <!--// end row -->
            </div>
            <!-- End Copyright -->
        </footer>
        <!--========== END FOOTER ==========-->
        
        <!-- Back To Top -->
        <a href="javascript:void(0);" class="js-back-to-top back-to-top">Top</a>

        <!-- JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
        <!-- CORE PLUGINS -->
        <script src="/vendor/jquery.min.js" type="text/javascript"></script>
        <script src="/vendor/jquery-migrate.min.js" type="text/javascript"></script>
        <script src="/vendor/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

        <!-- PAGE LEVEL PLUGINS -->
        <script src="/vendor/jquery.easing.js" type="text/javascript"></script>
        <script src="/vendor/jquery.back-to-top.js" type="text/javascript"></script>
        <script src="/vendor/jquery.smooth-scroll.js" type="text/javascript"></script>
        <script src="/vendor/jquery.wow.min.js" type="text/javascript"></script>
        <script src="/vendor/jquery.parallax.min.js" type="text/javascript"></script>
        <script src="/vendor/swiper/js/swiper.jquery.min.js" type="text/javascript"></script>

        <!-- PAGE LEVEL SCRIPTS -->
        <script src="/js/layout.min.js" type="text/javascript"></script>
        <script src="/js/components/wow.min.js" type="text/javascript"></script>
        <script src="/js/components/swiper.min.js" type="text/javascript"></script>

    </body>
    <!-- END BODY -->
</html>''')

conn.commit()
conn.close()
    
