print("content-type:text/html")
print()
print('''<!DOCTYPE html>
<!-- Template by Quackit.com -->
<!-- Images by various sources under the Creative Commons CC0 license and/or the Creative Commons Zero license. 
Although you can use them, for a more unique website, replace these images with your own. -->
<html lang="en">

<head>
   <script type="text/javascript">
      function preventBack()
      {
        window.history.forward();
        }
      setTimeout("preventBack()",0);
      window.onunload=function() { null };
    </script>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="/css/style.css">

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>login&Reg</title>

    <!-- Bootstrap Core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles -->
    <link href="/css/custom.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom Fonts from Google -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <script type="text/javascript">
        function validate( ) {
            // body...
            var pass = document.getElementById('pass').value;
            var usrename = /^[a-zA-Z0-9]+$]/;
            var pass1 = document.getElementById('pass1').value;
            var name = document.getElementById('name').value;
            var phone = document.getElementById('phone').value;

           

            if(pass.length<8)
            {
                alert("password must be min of length 8");
                return false;
            }
            if (!/^[a-zA-Z]*$/g.test(document.getElementById('name').value)) {
             alert("Invalid Name try removing special characters");
             return false;
            }

            if(pass!=pass1)
            {
                   alert("password missmatch");
            return false;
            }

               if(phone.length>=10)
            {
            
            
            }
            else
            {
                alert("Invalid Number")
                return false;
            }
        
         
        }

    </script>
    
</head>

<body>

    <!-- Navigation -->
    <nav id="siteNav" class="navbar navbar-default navbar-fixed-top affix" role="navigation" >
        <div class="container">
            <!-- Logo and responsive toggle -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#" style="color: green">
                	<span class="glyphicon glyphicon-fire"></span> 
                	RSMM-Articles
                </a>
            </div>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="nav navbar-nav navbar-right">
                    <li >
                        <a href="/index.html" style="color: black">Home</a>
                    </li>
                    <li class="active">
                        <a href="#">Login/Reg</a>
                    </li>
               
				
                    <li>
                        <a href="/cgi-bin/contact.py" style="color: black">aboutus</a>
                    </li>
                </ul>
                
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container -->
    </nav>

	<!-- Header -->
 

	<!-- Intro Section -->


	<!-- Content 1 -->
    <section class="content">
        <div class="container">
            <div class="row">
            
                            <div class="pen-title">
  <h1>Not a Member?</h1><span>Pen <i class='fa fa-paint-brush'></i> + <i class='fa fa-code'></i> by <a href='#'>Click the pen to join us!</a></span>
</div>
<!-- Form Module-->
<div class="module form-module">
  <div class="toggle"><i class="fa fa-times fa-pencil"></i>
    <div class="tooltip">Click Me</div>
  </div>
  <div class="form">
    <h2>Login to your account</h2>
    <form action="/cgi-bin/login2.py" method="post" >
        <div style="width: 100% ">
            <select style="width: 100%" name="ltype">
            <option value="User">User</option>
            <option value="Admin">Admin</option>
        </select>
        </div>
        <br>

        

      <input type="text" placeholder="enter e-mail" name="email" required />
      <input type="password" placeholder="Password" name="password" required />
      <BUTTON type="submit" >Log-in</BUTTON>
      <!-- <input type="submit" value="log-in">
 -->    </form>
  </div>
  <div class="form">
    <h2>Create an account</h2>
    <form action="/cgi-bin/second.py" method="post" onsubmit="return validate()">
            <div style="width: 100% ">
            <select style="width: 100%" name="rtype">
            <option>User</option>
            <option>Admin</option>
        </select>
        </div>
        <br>
    <!--    <br> -->
      <input type="text" name="username" placeholder="Username" required id="name"/>
      <input type="password" name="password" placeholder="Password" required id="pass" />
        <input type="password" name="re-password" placeholder="Re-enter password"  id="pass1" required/>
      <input type="email" name="email" placeholder="Email Address" required/>
       <input type="text" maxlength="10"  pattern="[0-9]{10}" placeholder="phonenumber" id= "phone" name="phno" required />
      <BUTTON type="submit" >Register</BUTTON>

<!--       <input type="submit" value="Register">
 -->

    </form>


  </div>
  <div class="cta"><a href="/forgot.html">Forgot your password?</a></div>
</div>           
                
            </div>
        </div>
    </section>

	<!-- Content 2 -->


    <!-- Promos -->
	<div class="container-fluid">
        <div class="row promo">
      
  
			
		
        </div>
    </div><!-- /.container-fluid -->

	<!-- Content 3 -->

    
	<!-- Footer -->
    <footer class="page-footer">
    
    	<!-- Contact Us -->
        <div class="contact">
        	<div class="container">
				<h2 class="section-heading">Contact Us</h2>
				<p><span class="glyphicon glyphicon-earphone"></span><br> +91 9502 80 4211</p>
				<p><span class="glyphicon glyphicon-envelope"></span><br> rsmm.articles@gmail.com</p>
        	</div>
        </div>
        	
        <!-- Copyright etc -->
        <div class="small-print">
        	<div class="container">
        		<p>Copyright &copy; RSMM-ARTICLES 2015</p>
        	</div>
        </div>
        
    </footer>

    <!-- jQuery -->
    <script src="/js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="/js/jquery.easing.min.js"></script>
    
    <!-- Custom Javascript -->
    <script src="/js/custom.js"></script>
      <script src='/http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='/https://codepen.io/andytran/pen/vLmRVp.js'></script>

    <script  src="/js/index.js"></script>

</body>

</html>''')
