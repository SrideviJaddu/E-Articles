import cgi,cgitb
cgitb.enable()
form=cgi.FieldStorage()
ltype=form.getvalue('ltype')
if ltype=='User':
    email=form.getvalue('email')
    password=form.getvalue('password')
    import sqlite3
    conn=sqlite3.connect('e-article1.db')
    d=conn.execute('''select * from users where
     email=? and password=?''',(email,password))
    data=d.fetchone()
    if(data):
        if(email==data[0] and password==data[3]):
            print('Set-Cookie:username=',data[2])
            print ('Set-Cookie:userid=',data[4])
            print ('Set-Cookie:Expires=Monday, 25-Dec-2017 15:20:00 GMT')
            print('Content-type:text/html')
            print()
            print('''<!DOCTYPE html>

<html lang="en" class="no-js">
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8"/>
        <title>Welcome ''',data[2],'''</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <meta content="" name="description"/>
        <meta content="" name="author"/>
           <script type="text/javascript">
      function preventBack()
      {
        window.history.forward();
        }
      setTimeout("preventBack()",0);
      window.onunload=function() { null };
    </script>

        <!-- GLOBAL MANDATORY STYLES -->
        <link href="/http://fonts.googleapis.com/css?family=Hind:300,400,500,600,700" rel="stylesheet" type="text/css">
        <link href="/vendor/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
        <link href="/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>

        <!-- PAGE LEVEL PLUGIN STYLES -->
        <link href="/css/animate.css" rel="stylesheet">
        <link href="/vendor/swiper/css/swiper.min.css" rel="stylesheet" type="text/css"/>

        <!-- THEME STYLES -->
        <link href="/css/layout.min.css" rel="stylesheet" type="text/css"/>

        <!-- Favicon -->
        <link rel="/shortcut icon" href="/favicon.ico"/>
    </head>
    <!-- END HEAD -->

    <!-- BODY -->
    <body>

        <!--========== HEADER ==========-->
        <header class="header navbar-fixed-top">
            <!-- Navbar -->
            <nav class="navbar" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="menu-container">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".nav-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="toggle-icon"></span>
                        </button>

                        <!-- Logo -->
                        <div class="logo">
                            <a class="logo-wrap" href="index.html">
                                <img class="logo-img logo-img-main" src="/img/logo.png" alt="Asentus Logo">
                                <img class="logo-img logo-img-active" src="/img/logo-dark.png" alt="Asentus Logo">
                            </a>
                        </div>
                        <!-- End Logo -->
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse nav-collapse">
                        <div class="menu-container">
                            <ul class="navbar-nav navbar-nav-right">
                                <li class="nav-item"><a class="nav-item-child nav-item-hover" href="#">''',data[2],'''</a></li>
                                <li class="nav-item"><a class="nav-item-child nav-item-hover" href="/cgi-bin/view.py">view Articles</a></li>
                                 <li class="nav-item"><a class="nav-item-child nav-item-hover" href="/cgi-bin/myarticles.py">My Articles</a></li>
                                  <li class="nav-item"><a class="nav-item-child nav-item-hover" href="/cgi-bin/save.py">saved articles</a></li>
                                  <li class="nav-item"><a class="nav-item-child nav-item-hover" href="/cgi-bin/test.py">Log-out</a></li>


                              


                             
                            </ul>
                        </div>
                    </div>
                    <!-- End Navbar Collapse -->
                </div>
            </nav>
            <!-- Navbar -->
        </header>
        <!--========== END HEADER ==========-->

        <!--========== PARALLAX ==========-->
        <div class="parallax-window" data-parallax="scroll" data-image-src="/img/1920x1080/01.jpg">
            <div class="parallax-content container">
                <h3 style="font-size: 40px" class="carousel-title">Welcome to RSMM</h3>
                <p>submit your articles and get massive online exposure</p>
                <b><p>Scroll Down to post articles</p></b>
            </div>
        </div>
        <!--========== PARALLAX ==========-->

        <!--========== PAGE LAYOUT ==========-->
        <!-- Pricing -->
     
        <!-- End Pricing -->

        <!-- Testimonials -->
           
  
        <!-- End Testimonials -->

        <!-- Clients -->
             <!-- End Clients -->
        <!--========== END PAGE LAYOUT ==========-->

        <!--========== FOOTER ==========-->
        <footer class="footer" style="background: #3B3738">
            <!-- Links -->
            <div class="footer-seperator">
                <div class="content-lg container">
                    <div class="row">
               
                    
                        <div class="col-sm-5 sm-margin-b-30">
                            <h2 class="color-white" >Add Article Here</h2>
                            <form action='profile1.py' method='post'>
                                <input type="text" class="form-control footer-input margin-b-20" name="Title" style="color:white" placeholder="Title" required>
                                <input type="text" class="form-control footer-input margin-b-20" name="Author" style="color:white"  placeholder="Author" required>
                                <textarea class="form-control footer-input margin-b-30" rows="6" name="Article" style="color:white" placeholder="Your Article Here" required></textarea>
                                <input type="hidden" name="arid">
                                <input type="hidden" name="status" value="0">

                                <button type="submit" class="btn-theme btn-theme-sm btn-base-bg text-uppercase">Add Article</button>
                            </form>
                            
<!--                             <input type="email" class="form-control footer-input margin-b-20" placeholder="Email" required>
 -->                            
<!--                             <textarea class="form-control footer-input margin-b-30" rows="6" placeholder="Message" required></textarea>
 -->                            
                        </div>
                    </div>
                    <!--// end row -->
                </div>
            </div>
            <!-- End Links -->

            <!-- Copyright -->
            <div class="content container">
                <div class="row">
                  
                    <div align="center">
                        <p class="margin-b-0"><a class="color-base fweight-700" href="#">RSMM</a> Theme Powered by: <a class="color-base fweight-700" href="#">Rahul. K</a></p>
                    </div>
                </div>
                <!--// end row -->
            </div>
            <!-- End Copyright -->
        </footer>
        <!--========== END FOOTER ==========-->
        ''')
            """for each in rd:
                print('''
                
                    
          <div class="content-lg container">
            <div class="row">
                <div class="col-sm-9">
                    <h2>TITLE</h2>''',each[0],'''

                    <!-- Swiper Testimonials -->
                    <div class="swiper-slider swiper-testimonials">
                        <!-- Swiper Wrapper -->
                        <div class="swiper-wrapper">'''
                                   ,each[2],'''
            
                            
                                <blockquote class="blockquote">
                                    <div class="margin-b-20">
                                
                                        
                                    </div>
                                    <p><span class="fweight-700 color-link">''',each[1],'''</span></p>
                                </blockquote>
                           
                        </div>
                        <!-- End Swiper Wrapper -->

                        <!-- Pagination -->
                        <div class="swiper-testimonials-pagination"></div>
                    </div>
                    <!-- End Swiper Testimonials -->
                    
                </div>
            </div>
            <!--// end row -->
        </div>''')"""
            print('''
  

        <!-- Back To Top -->
        <a href="javascript:void(0);" class="js-back-to-top back-to-top">Top</a>

        <!-- JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
        <!-- CORE PLUGINS -->
        <script src="/vendor/jquery.min.js" type="text/javascript"></script>
        <script src="/vendor/jquery-migrate.min.js" type="text/javascript"></script>
        <script src="/vendor/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

        <!-- PAGE LEVEL PLUGINS -->
        <script src="/vendor/jquery.easing.js" type="text/javascript"></script>
        <script src="/vendor/jquery.back-to-top.js" type="text/javascript"></script>
        <script src="/vendor/jquery.smooth-scroll.js" type="text/javascript"></script>
        <script src="/vendor/jquery.wow.min.js" type="text/javascript"></script>
        <script src="/vendor/jquery.parallax.min.js" type="text/javascript"></script>
        <script src="/vendor/swiper/js/swiper.jquery.min.js" type="text/javascript"></script>

        <!-- PAGE LEVEL SCRIPTS -->
        <script src="/js/layout.min.js" type="text/javascript"></script>
        <script src="/js/components/wow.min.js" type="text/javascript"></script>
        <script src="/js/components/swiper.min.js" type="text/javascript"></script>

    </body>
    <!-- END BODY -->
</html>

                          ''')
            conn.commit()
            conn.close()
    else:
        print("content-type:text/html")
        print()
        print('''<!DOCTYPE html>
<!-- Template by Quackit.com -->
<!-- Images by various sources under the Creative Commons CC0 license and/or the Creative Commons Zero license. 
Although you can use them, for a more unique website, replace these images with your own. -->
<html lang="en">

<head>
     <link rel="stylesheet" href="/https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='/https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='/https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="/css/style.css">

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>User login failed</title>

    <!-- Bootstrap Core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles -->
    <link href="/css/custom.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="/https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="/https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom Fonts from Google -->
    <link href='/http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
        <script type="text/javascript">
        function validate( ) {
            // body...
            var pass = document.getElementById('pass').value;
            var pass1 = document.getElementById('pass1').value;
            var name = document.getElementById('name').value;
            var phone = document.getElementById('phone').value;
            if(name.length<=5)
            {
                alert("Invalid name");
                return false;
            }

            if(pass.length<8)
            {
                alert("password must be min of length 8");
                return false;
            }

            if(pass!=pass1)
            {
                   alert("password missmatch");
            return false;
            }

               if(phone.length>=10)
            {
            
            
            }
            else
            {
                alert("Invalid Number")
                return false;
            }
         
         
        }

    </script>

    
</head>

<body>

    <!-- Navigation -->
    <nav id="siteNav" class="navbar navbar-default navbar-fixed-top affix" role="navigation" >
        <div class="container">
            <!-- Logo and responsive toggle -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#" style="color: green">
                	<span class="glyphicon glyphicon-fire"></span> 
                	RSMM-Articles
                </a>
            </div>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="nav navbar-nav navbar-right">
                    <li >
                        <a href="/index.html" style="color: black">Home</a>
                    </li>
                    <li class="active">
                        <a href="#">Login/Reg</a>
                    </li>
               
				
                    <li>
                        <a href="/aboutus.html" style="color: black">aboutus</a>
                    </li>
                </ul>
                
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container -->
    </nav>

	<!-- Header -->
 

	<!-- Intro Section -->


	<!-- Content 1 -->
   <section class="content">
        <div class="container">
            <div class="row">
  
                  <div align='center'>
                            
                     <h1>Incorrect email or password</h1><br><br> <a href='#' style="color:red">Try Again</a>
</div>
<!-- Form Module-->
<div class="module form-module">
  <div>
    <div class="tooltip">Click Me</div>
  </div>
  <div class="form">
    <h2>Login to your account</h2>
    <form action="/cgi-bin/login2.py" method="post" >
        <div style="width: 100% ">
            <select style="width: 100%" name="ltype">
            <option value="User">User</option>
            <option value="Admin">Admin</option>
        </select>
        </div>
        <br>

        

      <input type="text" placeholder="enter e-mail" name="email" required />
      <input type="password" placeholder="Password" name="password" required />
      <BUTTON type="submit" >Log-in</BUTTON>
      <!-- <input type="submit" value="log-in">
 -->    </form>
  </div>
  <div class="form">
    <h2>Create an account</h2>
    <form action="/cgi-bin/second.py" method="post" onsubmit="return validate()">
            <div style="width: 100% ">
            <select style="width: 100%" name="rtype">
            <option>User</option>
            <option>Admin</option>
        </select>
        </div>
        <br>
    <!--    <br> -->
      <input type="text" name="username" placeholder="Username" required id="name"/>
      <input type="password" name="password" placeholder="Password" required id="pass" />
        <input type="password" name="re-password" placeholder="Re-enter password"  id="pass1" required/>
      <input type="email" name="email" placeholder="Email Address" required/>
      <input type="tel" name="phno" placeholder="Phone Number" required id="phone" />
      <BUTTON type="submit" >Register</BUTTON>

<!--       <input type="submit" value="Register">
 -->

    </form>


  </div>
  <div class="cta"><a href="/forgot.html">Forgot your password?</a></div>
</div>           
                
            </div>
        </div>
    </section>

	<!-- Content 2 -->


    <!-- Promos -->
	<div class="container-fluid">
        <div class="row promo">
      
  
			
		
        </div>
    </div><!-- /.container-fluid -->

	<!-- Content 3 -->

    
	<!-- Footer -->
    <footer class="page-footer">
    
    	<!-- Contact Us -->
        <div class="contact">
        	<div class="container">
				<h2 class="section-heading">Contact Us</h2>
				<p><span class="glyphicon glyphicon-earphone"></span><br> +91 9502 80 4211</p>
				<p><span class="glyphicon glyphicon-envelope"></span><br> rsmm.articles@gmail.com</p>
        	</div>
        </div>
        	
        <!-- Copyright etc -->
        <div class="small-print">
        	<div class="container">
        		<p>Copyright &copy; RSMM-ARTICLES 2015</p>
        	</div>
        </div>
        
    </footer>

    <!-- jQuery -->
    <script src="/js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="/js/jquery.easing.min.js"></script>
    
    <!-- Custom Javascript -->
    <script src="/js/custom.js"></script>
      <script src='/http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='/https://codepen.io/andytran/pen/vLmRVp.js'></script>

    <script  src="/js/index.js"></script>

</body>

</html>''')



if ltype=='Admin':
    aemail=form.getvalue('email')
    apassword=form.getvalue('password')
    import sqlite3
    conn=sqlite3.connect('e-article1.db')
    d=conn.execute('''select * from admin where
    aemail=? and apassword=?''',(aemail,apassword))
    data=d.fetchone()
    x=conn.execute('''select * from article where status=0''')
    rd=x.fetchall()
    if(data):
        if(aemail==data[0] and apassword==data[3]):
            print('Set-Cookie:username=',data[2])
            print ('Set-Cookie:Expires=Monday, 25-Dec-2017 15:20:00 GMT')
            print('Content-type:text/html')
            print()
            print('''<!DOCTYPE html>

<html lang="en" class="no-js">
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8"/>
        <title>Welcome''',data[2],'''</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <meta content="" name="description"/>
        <meta content="" name="author"/>
        
   <script type="text/javascript">
      function preventBack()
      {
        window.history.forward();
        }
      setTimeout("preventBack()",0);
      window.onunload=function() { null };
    </script>

        <!-- GLOBAL MANDATORY STYLES -->
        <link href="/http://fonts.googleapis.com/css?family=Hind:300,400,500,600,700" rel="stylesheet" type="text/css">
        <link href="/vendor/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
        <link href="/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>

        <!-- PAGE LEVEL PLUGIN STYLES -->
        <link href="/css/animate.css" rel="stylesheet">
        <link href="/vendor/swiper/css/swiper.min.css" rel="stylesheet" type="text/css"/>

        <!-- THEME STYLES -->
        <link href="/css/layout.min.css" rel="stylesheet" type="text/css"/>

        <!-- Favicon -->
        <link rel="/shortcut icon" href="/favicon.ico"/>
    </head>
    <!-- END HEAD -->

    <!-- BODY -->
    <body>

        <!--========== HEADER ==========-->
        <header class="header navbar-fixed-top">
            <!-- Navbar -->
            <nav class="navbar" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="menu-container">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".nav-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="toggle-icon"></span>
                        </button>

                        <!-- Logo -->
                        <div class="logo">
                            <a class="logo-wrap" href="index.html">
                                <img class="logo-img logo-img-main" src="/img/logo.png" alt="Asentus Logo">
                                <img class="logo-img logo-img-active" src="/img/logo-dark.png" alt="Asentus Logo">
                            </a>
                        </div>
                        <!-- End Logo -->
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse nav-collapse">
                        <div class="menu-container">
                            <ul class="navbar-nav navbar-nav-right">
                                <li class="nav-item"><a class="nav-item-child nav-item-hover active" href="#">''',data[2],'''</a></li>
                                <li class="nav-item"><a class="nav-item-child nav-item-hover" href="/cgi-bin/aview.py">View Articles</a></li>
                                 <li class="nav-item"><a class="nav-item-child nav-item-hover" href="/cgi-bin/promote.py">Promote Articles</a></li>
                                <li class="nav-item"><a class="nav-item-child nav-item-hover" href="/cgi-bin/test.py">Log-out</a></li>


                              


                             
                            </ul>
                        </div>
                    </div>
                    <!-- End Navbar Collapse -->
                </div>
            </nav>
            <!-- Navbar -->
        </header>
        
        <!--========== END HEADER ==========-->

        <!--========== PARALLAX ==========-->
        <div class="parallax-window" data-parallax="scroll" data-image-src="/img/1920x1080/01.jpg">
            <div class="parallax-content container">
                <h3 style="font-size: 40px" class="carousel-title">Welcome to RSMM</h3>
                <p>This is a place where you are going to exlpore everything. Add your own articles and more<br/> Happy reading ;)</p>
                <b><p>Scroll Down to Login</p></b>
            </div>
        </div>
        <!--========== PARALLAX ==========-->

        <!--========== PAGE LAYOUT ==========-->
        <!-- Pricing -->
     
        <!-- End Pricing -->

        <!-- Testimonials -->
           
  
        <!-- End Testimonials -->

        <!-- Clients -->
             <!-- End Clients -->
        <!--========== END PAGE LAYOUT ==========-->
        <div class="promo-section overflow-h">
            <div class="container">
                <div class="clearfix">
                    <div class="ver-center">
                        <div class="ver-center-aligned">
                            <div class="promo-section-col">
                                <h2>Our Admins</h2>
                                <p>Every admin is instructed to view the articles that are to be promoted with high priority. No spam content shoould be promoted as it might affect the impression of users on the articles.</p>
                                <p>All the admins are under our survilence and are checked that they are genuine at regular periods. If you think you are not apt to promote the article leave that article and they might be promoted by other fellow admins.</p>
                                <p>Admins are the core to this website so please be cautious to promote an article and every admin is strictly instructed not to promote silly articles for the users</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="promo-section-img-right">
                <img class="img-responsive" src="/img/970x970/01.jpg" alt="Content Image">
            </div>
        </div>

        <!--========== FOOTER ==========-->
        <footer class="footer" style="background: white">
            <!-- Links -->
            <div class="footer-seperator">
                <div class="content-lg container">
                    <div class="row">
               
                    
                        <div class="col-sm-5 sm-margin-b-30">
                            
<!--                             <input type="email" class="form-control footer-input margin-b-20" placeholder="Email" required>
 -->                            
<!--                             <textarea class="form-control footer-input margin-b-30" rows="6" placeholder="Message" required></textarea>
 -->                            
                        </div>
                    </div>
                    <!--// end row -->
                </div>
            </div>
            <!-- End Links -->

            <!-- Copyright -->
            <div class="content container">
                <div class="row">
                
                    <div align="center">
                        <p class="margin-b-0"><a class="color-base fweight-700" href="#">RSMM </a> Theme Powered by: <a class="color-base fweight-700" href="#">Rahul. K</a></p>
                    </div>
                </div>
                <!--// end row -->
            </div>
            <!-- End Copyright -->
        </footer>
        <!--========== END FOOTER ==========-->
        ''')
            """for each in rd:
                print('''
                
                    
          <div class="content-lg container">
            <div class="row">
                <div class="col-sm-9">
                    <h2>TITLE</h2>''',each[0],'''<br>
                     <form>
                        <input type="text" name="arid"  
                    <!-- Swiper Testimonials -->
                    <div class="swiper-slider swiper-testimonials">
                        <!-- Swiper Wrapper -->
                        <div class="swiper-wrapper">'''
                                   ,each[2],'''
            
                            
                                <blockquote class="blockquote">
                                    <div class="margin-b-20">
                                
                                        
                                    </div>
                                    <p><span class="fweight-700 color-link">''',each[1],'''</span></p>
                                </blockquote>
                           
                        </div>
                        <!-- End Swiper Wrapper -->

                        <!-- Pagination -->
                        <div class="swiper-testimonials-pagination"></div>
                    </div>
                    <!-- End Swiper Testimonials -->
                    <button type="submit" class="btn-theme btn-theme-sm btn-base-bg text-uppercase">Add Article</button>
 
                    
                </div>
            </div>
            <!--// end row -->
        </div>''')"""
            print('''
  

        <!-- Back To Top -->
        <a href="javascript:void(0);" class="js-back-to-top back-to-top">Top</a>

        <!-- JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
        <!-- CORE PLUGINS -->
        <script src="/vendor/jquery.min.js" type="text/javascript"></script>
        <script src="/vendor/jquery-migrate.min.js" type="text/javascript"></script>
        <script src="/vendor/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

        <!-- PAGE LEVEL PLUGINS -->
        <script src="/vendor/jquery.easing.js" type="text/javascript"></script>
        <script src="/vendor/jquery.back-to-top.js" type="text/javascript"></script>
        <script src="/vendor/jquery.smooth-scroll.js" type="text/javascript"></script>
        <script src="/vendor/jquery.wow.min.js" type="text/javascript"></script>
        <script src="/vendor/jquery.parallax.min.js" type="text/javascript"></script>
        <script src="/vendor/swiper/js/swiper.jquery.min.js" type="text/javascript"></script>

        <!-- PAGE LEVEL SCRIPTS -->
        <script src="/js/layout.min.js" type="text/javascript"></script>
        <script src="/js/components/wow.min.js" type="text/javascript"></script>
        <script src="/js/components/swiper.min.js" type="text/javascript"></script>

    </body>
    <!-- END BODY -->
</html>

                          ''')
            conn.commit()
            conn.close()
    else:
        print("content-type:text/html")
        print()
        print('''<!DOCTYPE html>
<!-- Template by Quackit.com -->
<!-- Images by various sources under the Creative Commons CC0 license and/or the Creative Commons Zero license. 
Although you can use them, for a more unique website, replace these images with your own. -->
<html lang="en">

<head>
     <link rel="stylesheet" href="/https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='/https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='/https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="/css/style.css">

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>Admin login failed</title>

    <!-- Bootstrap Core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles -->
    <link href="/css/custom.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="/https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="/https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom Fonts from Google -->
    <link href='/http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
        <script type="text/javascript">
        function validate( ) {
            // body...
            var pass = document.getElementById('pass').value;
            var pass1 = document.getElementById('pass1').value;
            var name = document.getElementById('name').value;
            var phone = document.getElementById('phone').value;
            if(name.length<=5)
            {
                alert("Invalid name");
                return false;
            }

            if(pass.length<8)
            {
                alert("password must be min of length 8");
                return false;
            }

            if(pass!=pass1)
            {
                   alert("password missmatch");
            return false;
            }

               if(phone.length>=10)
            {
            
            
            }
            else
            {
                alert("Invalid Number")
                return false;
            }
         
         
        }

    </script>

    
</head>

<body>

    <!-- Navigation -->
    <nav id="siteNav" class="navbar navbar-default navbar-fixed-top affix" role="navigation" >
        <div class="container">
            <!-- Logo and responsive toggle -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#" style="color: green">
                	<span class="glyphicon glyphicon-fire"></span> 
                	RSMM-Articles
                </a>
            </div>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="nav navbar-nav navbar-right">
                    <li >
                        <a href="/index.html" style="color: black">Home</a>
                    </li>
                    <li class="active">
                        <a href="#">Login/Reg</a>
                    </li>
               
				
                    <li>
                        <a href="/aboutus.html" style="color: black">aboutus</a>
                    </li>
                </ul>
                
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container -->
    </nav>

	<!-- Header -->
 

	<!-- Intro Section -->


	<!-- Content 1 -->
  <section class="content">
        <div class="container">
            <div class="row">
            
                  <div align='center'>
                            
                     <h1>Incorrect email or password</h1> <br><br><a href='#' style="color:red">Try Again</a>
</div>
<!-- Form Module-->
<div class="module form-module">
  <div >
    <div class="tooltip">Click Me</div>
  </div>
  <div class="form">
    <h2>Login to your account</h2>
    <form action="/cgi-bin/login2.py" method="post" >
        <div style="width: 100% ">
            <select style="width: 100%" name="ltype">
            <option value="User">User</option>
            <option value="Admin">Admin</option>
        </select>
        </div>
        <br>

        

      <input type="text" placeholder="enter e-mail" name="email" required />
      <input type="password" placeholder="Password" name="password" required />
      <BUTTON type="submit" >Log-in</BUTTON>
      <!-- <input type="submit" value="log-in">
 -->    </form>
  </div>
  <div class="form">
    <h2>Create an account</h2>
    <form action="/cgi-bin/second.py" method="post" onsubmit="return validate()">
            <div style="width: 100% ">
            <select style="width: 100%" name="rtype">
            <option>User</option>
            <option>Admin</option>
        </select>
        </div>
        <br>
    <!--    <br> -->
      <input type="text" name="username" placeholder="Username" required id="name"/>
      <input type="password" name="password" placeholder="Password" required id="pass" />
        <input type="password" name="re-password" placeholder="Re-enter password"  id="pass1" required/>
      <input type="email" name="email" placeholder="Email Address" required/>
      <input type="tel" name="phno" placeholder="Phone Number" required id="phone" />
      <BUTTON type="submit" >Register</BUTTON>

<!--       <input type="submit" value="Register">
 -->

    </form>


  </div>
  <div class="cta"><a href="/forgot.html">Forgot your password?</a></div>
</div>           
                
            </div>
        </div>
    </section>

	<!-- Content 2 -->


    <!-- Promos -->
	<div class="container-fluid">
        <div class="row promo">
      
  
			
		
        </div>
    </div><!-- /.container-fluid -->

	<!-- Content 3 -->

    
	<!-- Footer -->
    <footer class="page-footer">
    
    	<!-- Contact Us -->
        <div class="contact">
        	<div class="container">
				<h2 class="section-heading">Contact Us</h2>
				<p><span class="glyphicon glyphicon-earphone"></span><br> +91 9502 80 4211</p>
				<p><span class="glyphicon glyphicon-envelope"></span><br> rsmm.articles@gmail.com</p>
        	</div>
        </div>
        	
        <!-- Copyright etc -->
        <div class="small-print">
        	<div class="container">
        		<p>Copyright &copy; RSMM-ARTICLES 2015</p>
        	</div>
        </div>
        
    </footer>

    <!-- jQuery -->
    <script src="/js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="/js/jquery.easing.min.js"></script>
    
    <!-- Custom Javascript -->
    <script src="/js/custom.js"></script>
      <script src='/http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='/https://codepen.io/andytran/pen/vLmRVp.js'></script>

    <script  src="/js/index.js"></script>

</body>

</html>''')
        
