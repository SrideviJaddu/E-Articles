import cgi,cgitb
import os
cgitb.enable()
form=cgi.FieldStorage()
import sqlite3
conn=sqlite3.connect("e-article1.db")
handler = {}
if 'HTTP_COOKIE' in os.environ:
     cookies = os.environ['HTTP_COOKIE']
     cookies = cookies.split('; ')
     for cookie in cookies:
          cookie = cookie.split('=')
          handler[cookie[0]] = cookie[1]
otp=form.getvalue('otp')
if(handler['otp']==otp):
    print("Content-type:text/html")
    print()
    print('''<!DOCTYPE html>
<!-- Template by Quackit.com -->
<!-- Images by various sources under the Creative Commons CC0 license and/or the Creative Commons Zero license. 
Although you can use them, for a more unique website, replace these images with your own. -->
<html lang="en">

<head>
     <link rel="stylesheet" href="/https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='/https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='/https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="/css/style.css">

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>Password verify</title>

    <!-- Bootstrap Core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles -->
    <link href="/css/custom.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="/https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="/https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom Fonts from Google -->
    <link href='/http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
     <script type="text/javascript">
        function validate( ) {
            // body...
            var pass = document.getElementById('pass').value;
            var pass1 = document.getElementById('pass1').value;


           

            if(pass.length<8)
            {
                alert("password must be min of length 8");
                return false;
            }

            if(pass!=pass1)
            {
                   alert("password missmatch");
            return false;
            }

    
        
         
        }

    </script>
    
</head>

<body>

    <!-- Navigation -->
        <nav id="siteNav" class="navbar navbar-default navbar-fixed-top" role="navigation" >
         <div class="container">
            <!-- Logo and responsive toggle -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#" style="color: green">
                	<span class="glyphicon glyphicon-fire"></span> 
                	RSMM-Articles
                </a>
            </div>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="nav navbar-nav navbar-right">
                    <li class="active">
                        <a href="/index.html">Home</a>
                    </li>
                  
                </ul>
                
            </div><!-- /.navbar-collapse -->
        </div>
           
            <!-- Navbar links --><!-- /.navbar-collapse -->
        </div><!-- /.container -->
    </nav>

    <!-- Header -->
 

    <!-- Intro Section -->


    <!-- Content 1 -->
    <section class="content">
        <div class="container">
            <div class="row">
            
             
 
                     
                     <div class="pen-title">
  <h1>Forgot Password</h1><span><a href='#'>Enter Your new password to change</a></span>
</div>
<!-- Form Module-->
<div class="module form-module">
  <div>
    <div class="tooltip">Click Me</div>
  </div>
  <div class="form">
    <h2>Enter New password</h2>
    <form action='/cgi-bin/changep.py' method='post' onsubmit="return validate()">
        <div style="width: 100% ">
        <!--    <select style="width: 100%" name="ltype">
            <option value="Admin">Admin</option>
            <option value="User">User</option>
        </select>-->
        </div> 
        
        

      <input type="password" name="password" placeholder="New Password" required id="pass" />
        <input type="password" name="re-password" placeholder="Re-enter new password"  id="pass1" required/>
    

<!--       -->      <BUTTON type="submit">Change Password</BUTTON>    
</form>
   
  </div>
  <div class="module form-module"></div>
</div>
                
<!-- Form Module-->

                         
                
            </div>
        </div>
    </section>

    <!-- Content 2 -->


    <!-- Promos -->
    <div class="container-fluid">
        <div class="row promo">
      
  
            
        
        </div>
    </div><!-- /.container-fluid -->

    <!-- Content 3 -->

    
    <!-- Footer -->
    <footer class="page-footer">
    
        <!-- Contact Us -->
        <div class="contact" style="background: #33b5e5">
            <div class="container">
                <h2 class="section-heading">Contact Us</h2>
                <p><span class="glyphicon glyphicon-earphone"></span><br> +91 9502 80 4211</p>
                <p><span class="glyphicon glyphicon-envelope"></span><br> rsmm.articles@gmail.com</p>
            </div>
        </div>
            
        <!-- Copyright etc -->
        <div class="small-print">
            <div class="container">
                <p>Copyright &copy; RSMM-ARTICLES 2015</p>
            </div>
        </div>
        
    </footer>

    <!-- jQuery -->
    <script src="/js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="/js/jquery.easing.min.js"></script>
    
    <!-- Custom Javascript -->
    <script src="js/custom.js"></script>
      <script src='/http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script  src="/js/index.js"></script>

</body>

</html>
''')
else:
    print("Content-type:text/html")
    print()
    print('''<html>
<head>
	<style type="text/css">
		body{
	background :linear-gradient(to bottom right, white , #999caa) ;
	height: 600px;
}
   
   a{
   	font-family: Hind,sans-serif;
   	font-size: 40px;
   	    -webkit-font-smoothing: antialiased;
   	    color: #515769;
   	    text-decoration: none;
   	    padding: none;
   	    margin: 0px;
   	        background-color: transparent;
   }
   a:hover {
    outline: 0;
    color: #999caa;
    text-decoration: none;
}
	h1{
		 	font-family: Hind,sans-serif;
   	font-size: 40px;
   	    -webkit-font-smoothing: antialiased;
   	    color: #515769;
   	     background-color: transparent;
   	        	    margin: 0px;


	}
</style>

</head>
      <body>
       <center><h1><a href="/forgot.html">The Entered OTP is Incorrect!</a></h1>
       	<h1 style="font-size: 22px">(Go back and Receive an OTP)</h1>

       	<div>
       	<img src="/images/warn.png" alt="Sorry" height="500" style="padding-top: 0px;">
       	</div>
       </center>
   		</body>
                        
</html>''')
    
    
